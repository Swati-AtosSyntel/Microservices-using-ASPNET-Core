﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatalogService.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }

        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    Name = "Electronics"
                    
                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Clothes"
                   
                },
                new Category
                {
                    CategoryId = 3,
                    Name = "Grocery"
                    
                }
            );
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 123,
                    ProductName = "Dell Laptop",
                    Description="Electronics Appliances",
                    CategoryId=1

                },
                new Product
                {
                    ProductId = 124,
                    ProductName = "Sony Tv",
                    Description = "Electronics Appliances",
                    CategoryId = 1
                }
               
            );
        }

    }
}
